<?php

	\thebuggenie\core\framework\Context::getI18n()->setCharset('utf-8');
	setlocale(LC_ALL, array('ru_RU.UTF-8', 'ru_RU', 'ru'));
